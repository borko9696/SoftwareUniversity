namespace IntervalTree
{
    public enum StubMode
    {
        Contains, 

        ContainsStart, 

        ContainsStartThenEnd
    }
}