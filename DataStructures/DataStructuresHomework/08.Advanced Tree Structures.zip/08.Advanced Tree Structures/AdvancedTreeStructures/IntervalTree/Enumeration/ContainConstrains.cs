namespace IntervalTree
{
    public enum ContainConstrains
    {
        None, 

        IncludeStart, 

        IncludeEnd, 

        IncludeStartAndEnd
    }
}